#include <asm/arch/firm/regs.h>
#include <asm/arch/firm/reg_addr.h>
#include <asm/arch/firm/timing.h>
#include <config.h>
#include <asm/arch/firm/io.h>
#include <asm/arch/firm/config.h>
#include <memtest.h>
static void __udelay(unsigned long usec);

#define debug_print(a)  serial_puts(a)
#define debug_print_char(a)  serial_putc(a)

#define debug_print_dword(a)  serial_put_dword(a)
#define debug_print_hex(a,b)  serial_put_hex(a,b)

STATIC_PREFIX datum   memTestDataBus(volatile datum * address);
STATIC_PREFIX datum * memTestAddressBus(volatile datum * baseAddress, unsigned long nBytes);
STATIC_PREFIX datum * memTestDevice(volatile datum * baseAddress, unsigned long nBytes);

#ifndef CONFIG_AML_UBOOT_MAGIC
#define CONFIG_AML_UBOOT_MAGIC 0x12345678
#endif

#define DDR_RSLR_LEN 6
#define DDR_RDGR_LEN 4
#define DDR_MAX_WIN_LEN (DDR_RSLR_LEN*DDR_RDGR_LEN)
static unsigned ddr_start_again=0;
#define APB_Wr(addr, data) WRITE_APB_REG(addr,data);__builtin_arc_sync();
#define APB_Rd(addr) READ_APB_REG(addr)
#include "ddr/util.c"
#include "ddr/level_1.c"
#include "ddr/ddr3.c"
#include "ddr/ddr2.c"
#if 1
#include "ddr/level_2.c"
#endif









STATIC_PREFIX unsigned ddr_init (struct ddr_set * ddr_setting)
{
	
	
	int i,j,k;
	unsigned ret=0;
    //Start manual data trainning
//	writel(RESET_DDR,P_RESET1_REGISTER);
//	init_dmc(ddr_setting);
//	if(ddr_setting->init_pctl(ddr_setting))
//	   return 1;
//    
    
    do{
        unsigned temp;
        ret=0;
        writel(RESET_DDR,P_RESET1_REGISTER);
        __udelay(1000);
        
        APB_Wr(MMC_DDR_CTRL, ddr_setting->ddr_ctrl);
        APB_Wr(MMC_REQ_CTRL,0xff);
    	if(ddr_setting->init_pctl(ddr_setting))
    	{
    	    debug_print("Faillll\n");
    	   return 1;
    	}
//    	dwc_pctl_stat(PCTL_STAT_Config);
//        writel(9,P_PCTL_RSLR0_ADDR);
//        writel(15,P_PCTL_RDGR0_ADDR);
//        break;
        
#if 0   
        ret=0;
//        hw_training();
   	    for (k = 0; k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) 
   	    {
            dwc_pctl_stat(PCTL_STAT_Config);
            ret|=dwc_level_1_sw(k)<<k;
            debug_print(" ");
            debug_print_hex(ret,8);
            debug_print("\n");
    	}
    	ret=0;
    	for (k = 0; k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) 
   	    {
            dwc_pctl_stat(PCTL_STAT_Config);
            ret|=dwc_level_1_sw(k)<<k;
            debug_print(" ");
            debug_print_hex(ret,8);
            debug_print("\n");
    	}
    	hw_training();
    	for (k = 0; k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) 
    	{
    	    if((ret&(1<<k))==0)
    	        continue;
            dwc_pctl_stat(PCTL_STAT_Config);
            ret&=~(1<<k);
            ret|=dwc_level_1_sw(k)<<k;
            debug_print(" ");
            debug_print_hex(ret,8);
            debug_print("\n");
            
    	
    	}
#else
        
        ret=hw_training();
#endif
        if(ret)
            continue;	
        print_registers();   
#if 0         
        for (k = 0; k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) 
        {
            dwc_level_2(k);
//            dwc_level_1_sw(k);
        }
#endif        
        for (k = 0; k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) 
    	{
    	    dwc_pctl_stat(PCTL_STAT_Config);
    	    pdm_write();
            pdm_dtu_enable(k,1); //enable write once and read multi mode	    
            pdm_run(1);
            debug_print("\nlane");
            debug_print_hex(k,8);
            for(i=0;i<0x100;i++)
            {
                
                pdm_run(0);
                unsigned char t=check_dtu();
                if(t!=0x10||readl(P_PCTL_DTUPDES_ADDR)){
                    debug_print("\n");
                    debug_print_hex(i,8);
    			    debug_print(" result:");
                    debug_print_hex(t,8);
                    debug_print_hex(check_prd(),8);
                    debug_print(" result: ");
                    debug_print_hex(readl(P_PCTL_DTUPDES_ADDR),32);
                    debug_print(" ");
                    print_prd();
                    debug_print(" ");
                    print_dtu();
                    break;
                }
            }
            if(i!=0x100)
                break;
        }
        if(i!=0x100)
        {
//            hw_training();
//            serial_getc();
            debug_print("\nrerun\n");
            continue;
        }
    	
        
	    if(ret){
	        print_registers(2);
	        serial_getc();
	        continue;
	    }
	    
	    
#if 0
	    for(k=0;k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) {
	        dwc_level_2(k);
	    }
#endif
//        hw_training();
//   	    for(i=0;i<0x10;i++){
//    	    for(k=0;k < ((ddr_setting->ddr_ctrl&(1<<7))?0x2:0x4); k++) {
//    	        dwc_pctl_stat(PCTL_STAT_Config);
//                pdm_write(k);
//    			pdm_run();
//    	        ret|=check_dtu()==0x10?0:1;
//    	    }
//    	    if(ret){
//    	        break;
//    	    }
//	    }
	    if(ret)
	   {
	        print_registers();
	        serial_getc();
	        continue;
        }

	}while(ret);
#if 1	
    save_registers(2);
    writel(RESET_DDR,P_RESET1_REGISTER);
    __udelay(1000);
    APB_Wr(MMC_DDR_CTRL, ddr_setting->ddr_ctrl);
    if(ddr_setting->init_pctl(ddr_setting))
	   return 1;
    dwc_pctl_stat(PCTL_STAT_Config);
    restore_registers(2);
    dwc_pctl_stat(PCTL_STAT_Access);	
    
    debug_print("\nDDR Finished\n");
    
#endif
    dwc_pctl_stat(PCTL_STAT_Config);
    print_registers(2);
    debug_print("DDR Finished????\n");
    APB_Wr(MMC_REQ_CTRL,0xff);
    dwc_pctl_stat(PCTL_STAT_Access);
//    APB_Wr(MMC_DDR_CTRL, ddr_setting->ddr_ctrl);//reset pin ???
    
    return 0;

}
STATIC_PREFIX void ddr_pll_init(struct ddr_set * ddr_setting) ;
static volatile unsigned * sw_train=(volatile unsigned *)0x4901fff0;

static inline unsigned lowlevel_ddr(void)
{
    struct ddr_set * ddr=&__ddr2_nanya_1Gbit;;
    int ret;
    if(POR_GET_DDR(romboot_info->por_cfg)==POR_DDR3)
    {
        debug_print("Init DDR3\n");
        ddr=&__ddr3_nanya_1Gbit;
    }else{
        debug_print("Init DDR2\n");
    }
    unsigned tag=*sw_train;
    ddr_pll_init(ddr);
    debug_print_dword(tag);
    
//    if(tag&1)
    if(1)
    {        
            while(ddr_init(ddr))ddr_start_again=0;
        
        
    }
    print_registers(2);
    tag++;
    *sw_train=tag;
    debug_print_dword(*sw_train);
    
    return 0;
}
static inline unsigned lowlevel_mem_test_device(void)
{
    return (unsigned)memTestDevice((volatile datum *)PHYS_MEMORY_START,PHYS_MEMORY_SIZE);
}
static inline unsigned lowlevel_mem_test_data(void)
{
    return (unsigned)memTestDataBus((volatile datum *) PHYS_MEMORY_START);
}
static inline unsigned lowlevel_mem_test_addr(void)
{
    return (unsigned)memTestAddressBus((volatile datum *)PHYS_MEMORY_START,
				    PHYS_MEMORY_SIZE);
}
static unsigned ( * mem_test[])(void)={
    lowlevel_ddr,
    lowlevel_mem_test_addr,
    lowlevel_mem_test_data,
#ifdef CONFIG_ENABLE_MEM_DEVICE_TEST
    lowlevel_mem_test_device
#endif
};
#define MEM_DEVICE_TEST_ITEMS (sizeof(mem_test)/sizeof(mem_test[0]))
#ifdef CONFIG_ENABLE_MEM_DEVICE_TEST
#define MEM_DEVICE_TEST_ITEMS_BASE (MEM_DEVICE_TEST_ITEMS -1)
#else
#define MEM_DEVICE_TEST_ITEMS_BASE (MEM_DEVICE_TEST_ITEMS -0)
#endif
STATIC_PREFIX unsigned ddr_init_test(void)
{
    int i,j;
    unsigned por_cfg=1;
    debug_print_char('\n');
    writel((0<<22)+0x186a0,P_WATCHDOG_TC);
    setbits_le32(0xc1100000+0x1111*4,1<<6);
    por_cfg=0;
#ifdef CONFIG_ENABLE_MEM_DEVICE_TEST    
    for(i=0;i<MEM_DEVICE_TEST_ITEMS_BASE+1&&por_cfg==0;i++)
#else    
    for(i=0;i<MEM_DEVICE_TEST_ITEMS_BASE&&por_cfg==0;i++)
#endif    
	{
	        writel(0,P_WATCHDOG_RESET);
	        debug_print("\nStage ");
	        debug_print_hex(i,8);
	        por_cfg=mem_test[i]();
	        debug_print(" Result ");
	        debug_print_hex(por_cfg,32);
	}
	i=0;
	por_cfg=0;
    while(por_cfg==0)
    {
        debug_print_hex(i++,8);
        por_cfg=mem_test[3]();
    }
	writel(0,P_WATCHDOG_TC);
	ddr_start_again=por_cfg?1:ddr_start_again;
	return por_cfg;
}





