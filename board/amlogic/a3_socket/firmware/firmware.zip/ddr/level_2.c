static char * phase_name[]={
    "90 ",
    "72 ",
    "54 ",
    "36 ",
    "108",
    "90 ",
    "72 ",
    "54 ",
    "126",
    "108",
    "90 ",
    "72 ",
    "144",
    "126",
    "108",
    "90 "
};
static unsigned char dllcr[]={3,2,1,0,0xe,0xd,0xc};
#define DLLCR_SIZE sizeof(dllcr)
static unsigned pdm_run_read(unsigned time,unsigned print)
{
    int i;
    unsigned fail=0;
    for(i=0;i<time;i++)
    {
        pdm_run(0);
        fail|=check_prd();
        if(print){
            debug_print(" ");
            debug_print_hex(fail,8);
        }
    }
    return fail;
}
static void dwc_dq_alignment(unsigned lane)
{
    unsigned dqdly,phase,i,j,fail,s_fail,dqtr,dtupdes;
    dqdly=0xf;
    phase=0;
    unsigned dllcr_reg=P_PCTL_DLLCR0_ADDR+(lane<<2);
    unsigned dqtr_reg=P_PCTL_DQTR0_ADDR+(lane<<2);
    dwc_pctl_stat(PCTL_STAT_Config);
    clrsetbits_le32(dllcr_reg,(0xf<<14),phase<<14);
    writel(-1,dqtr_reg);
    pdm_write();
    pdm_dtu_enable(lane,1);
    pdm_run(1);
    phase=0x10;
    s_fail=0;
    debug_print("\nlane");
    debug_print_hex(lane,8);
    debug_print(" DQ Alignment by Failure , step 1");
    print_registers();
    for(i=0;i<DLLCR_SIZE;i++)
    {
//        phase=i&0xf;
        phase=dllcr[i];
        dwc_pctl_stat(PCTL_STAT_Config);
        
        clrsetbits_le32(dllcr_reg,(0xf<<14),(phase&0xf)<<14);
    
        debug_print("\n");
        debug_print(phase_name[phase]);
        
        fail=pdm_run_read(10,1);
	    
    }
    for(i=4,j=3;i>0;i--)
    {
//        phase=i&0xf;
        phase=dllcr[i-1];
        dwc_pctl_stat(PCTL_STAT_Config);
        
        clrsetbits_le32(dllcr_reg,(0xf<<14),(phase&0xf)<<14);
    
        debug_print("\n");
        debug_print(phase_name[phase]);
        
        fail=pdm_run_read(10,1);
	    if(fail)
        {
            
            j=i;
            s_fail=fail;
            debug_print("Got");
            continue;
        }
    }
    dwc_pctl_stat(PCTL_STAT_Config);
    if(s_fail!=0)
    {
        phase=dllcr[j];
    }
    else{
        for(i=0;i<DLLCR_SIZE;i--)
        {
    //        phase=i&0xf;
            phase=dllcr[i];
            dwc_pctl_stat(PCTL_STAT_Config);
            
            clrsetbits_le32(dllcr_reg,(0xf<<14),(phase&0xf)<<14);
        
            debug_print("\n");
            debug_print(phase_name[phase]);
            
            fail=pdm_run_read(10,1);
    	    
        }
        phase=dllcr[0];
    }
    phase&=0xf;
        
    dwc_pctl_stat(PCTL_STAT_Config);
    clrsetbits_le32(dllcr_reg,(0xf<<14),phase<<14);
    debug_print("\n\n");
    debug_print(phase_name[phase]);
    fail=pdm_run_read(10,1);
    

    
    
    debug_print("\nSet DQTR , step 1");
    dqtr=0xffffffff;
    dtupdes=0;
    unsigned pass=0;
    debug_print("\nPHASE=");
    debug_print(phase_name[phase]);
    debug_print("\n");
    print_registers();
    for(i=0;i<0x10;i++)
    {
        dqdly=0xf-i;
	    
	    for(j=0;j<8;j++)
        {
            if(fail&(1<<j))
                continue;
            if(dtupdes&(1<<j))
                dqtr=(dqtr&(~(0xf<<(j*4))))|((dqdly+1)<<(j*4));
            else
                dqtr=(dqtr&(~(0xf<<(j*4))))|(dqdly<<(j*4));
        }
	    dwc_pctl_stat(PCTL_STAT_Config);
	    writel(dqtr,dqtr_reg);
        dtupdes=pdm_run_read(10,1);
        fail|=dtupdes;
        debug_print("\n");
        debug_print_hex(dqtr,32);
        debug_print(" ");
        debug_print_hex(dtupdes,8);
        debug_print(" ");
        debug_print_hex(fail,8);
    }
    for(j=0;j<8;j++)
    {
        unsigned temp=(dqtr>>(j*4));
        if(fail&(1<<j))
        {
            
            temp=temp;
            
        }
        else
            temp=0;
        dqtr=(dqtr&(~(0xf<<(j*4))))|(temp<<(j*4));
    }
    debug_print_dword(dqtr);
    dwc_pctl_stat(PCTL_STAT_Config);
    writel(dqtr,dqtr_reg);
    clrsetbits_le32(dllcr_reg,(0xf<<14),0<<14);
    print_registers(2);
	    
}
#if 1
static void dwc_dqs(unsigned lane)
{
    unsigned i,dqsdly,phase;
    unsigned dllcr_reg=P_PCTL_DLLCR0_ADDR+(lane<<2);
    unsigned dqtr_reg=P_PCTL_DQTR0_ADDR+(lane<<2);
    dwc_pctl_stat(PCTL_STAT_Config);
    clrsetbits_le32(dllcr_reg,(0xf<<14),3<<14);
    pdm_write();
    pdm_dtu_enable(lane,1);
    pdm_run(1);
    unsigned pass=0xff,flag=0;
    unsigned middle;
    unsigned last_s=0xff,last_e=0xff;
    unsigned s=128;
    debug_print("\nEnter DQS Test\n");
    for(i=0x0;i<DLLCR_SIZE*8;i++)
    {
        phase=dllcr[(i>>3)&7];
        
        dqsdly=(i)&7;
        dwc_pctl_stat(PCTL_STAT_Config);
        if(dqsdly==0)
        {
            debug_print("\n");
            debug_print(phase_name[phase]);
            debug_print(" ");
        }
        clrsetbits_le32(dllcr_reg,(0xf<<14),phase<<14);
        
	    clrsetbits_le32(P_PCTL_DQSTR_ADDR,(0x7<<(lane*3)),(dqsdly<<(lane*3)));
	    clrsetbits_le32(P_PCTL_DQSNTR_ADDR,(0x7<<(lane*3)),(dqsdly<<(lane*3)));
	    
        unsigned prd;
        prd=pdm_run_read(10,0);
        debug_print(" ");
        debug_print_hex(prd,8);
        if(prd==0&&(pass==0xff))
        {
            flag=1;
            pass=i;
        }
        if(prd!=0&&pass!=0xff)
        {
            if(last_e-last_s<i-pass)
            {
                last_s=pass;
                last_e=i;
            }
            s=i;    
            pass=0xff;
            continue;
        }
        
    }
    if(flag)
    {
        if(pass!=0xff&&last_e-last_s<i-pass)
        {
            last_s=pass;
            last_e=i;
        }

        
        
        middle =((last_e+last_s)>>1);
    }else{
        middle=0x1c;
        debug_print("Some thing error");
    }
    dqsdly=middle&0x7;
    phase=(((middle>>3)&0xf)-3)&0xf;
    
    debug_print("\nGet Windows From ");
    debug_print_hex(last_s,8);
    debug_print(" to ");
    debug_print_hex(last_e,8);
    debug_print(",best is ");
    debug_print_hex(middle,8);
    
    debug_print("\nresult\nDQSDLY=");
    debug_print_hex(dqsdly,8);
    debug_print(" DLLCR=");
    debug_print_hex(phase,8);
    debug_print("\n");
    dwc_pctl_stat(PCTL_STAT_Config);
    clrsetbits_le32(dllcr_reg,(0xf<<14),phase<<14);
    
    clrsetbits_le32(P_PCTL_DQSTR_ADDR,(0x7<<(lane*3)),(dqsdly<<(lane*3)));
    clrsetbits_le32(P_PCTL_DQSNTR_ADDR,(0x7<<(lane*3)),(dqsdly<<(lane*3)));
    dwc_pctl_stat(PCTL_STAT_Access);
    
}
#endif
STATIC_PREFIX void dwc_level_2(unsigned lane)
{
    dwc_dq_alignment(lane);
    dwc_dqs(lane);
//    serial_getc();
}
