static int init_pctl_ddr3(struct ddr_set * ddr_setting)
{
    int i;
    int mrs0_value;
    int mrs1_value;
    int mrs2_value;
    int mrs3_value;
//    writel(RESET_DDR,P_RESET1_REGISTER);

    for(i=0;i<0x1000;i++);
    mrs0_value =          (1 << 12 ) |   // 1 fast, 0 slow.
                            (4 <<9 )   |   //wr recovery   4 means write recovery = 8 cycles..
                            (0  << 8 ) |   //DLL reset.
                            (0  << 7 ) |   //0= Normal 1=Test.
                            (4  << 4 ) |   //cas latency high bits.
                            (0  << 3 ) |   //burst type,  0:sequential 1 Interleave.
                            (0  << 2 ) |   //cas latency bit 0.
                                   0 ;     //burst length  :  2'b00 fixed BL8 
    
    
    
    mrs1_value =     (0 << 12 )  | // qoff 0=op buf enabled : 1=op buf disabled  (A12)
                     (0 << 11 )  | // rdqs enable 0=disabled : 1=enabled                (A11)
                     (0 << 7  )  |  // Write leveling enable;      // 0=disable : 1=enable
                     (((ddr_setting->cl-ddr_setting->t_al)&3) << 3) | //additive_latency; // 0 - 4                                 (A5-A3)
                     ( 0 << 9)   |
                     ( 0 << 6)   |
                     ( 1 << 2)   | //ODT;    //(A9, A6, A2) 0=disable : 1=Rzq/4 : 2=Rzq/2 : 3=Rzq/6 : 4=Rzq/12 : 5=Rzq/8 
                     ( 0 << 5)   |
                     ( 0 << 1 )  | //ocd_impedence;    // (A5, A1) 0=Rzq/6 : 1=Rzq/7
                     ( 0 << 0 ) ;  // dll_enable;       // 0=enable : 1=disable

    mrs2_value =  1 << 3;
    mrs3_value = 0;
    
//    APB_Wr(MMC_DDR_CTRL, ddr_setting->ddr_ctrl);//reset pin ???
    //configure basic DDR PHY parameter.
      APB_Wr(PCTL_TOGCNT1U_ADDR, ddr_setting->t_1us_pck);
      APB_Wr(PCTL_TOGCNT100N_ADDR, ddr_setting->t_100ns_pck);
      APB_Wr(PCTL_TINIT_ADDR, ddr_setting->t_init_us);

      // to disalbe cmd lande receiver current. 
      // we don't need receive data from command lane.
//     APB_Wr(MMC_PHY_CTRL,   1 );  

      //configure DDR PHY power down/self refresh power saving mode.
//    APB_Wr(PCTL_IOCR_ADDR, (APB_Rd(PCTL_IOCR_ADDR) & 0xffff00ff) | ((ddr_setting->ddr_ctrl&(1<<7))?0x300:0xf00));
    
      APB_Wr(PCTL_IOCR_ADDR, 0xfe0c03fd);//???
      

      if ( 0 ) {
         APB_Wr(PCTL_TRSTH_ADDR, 500);       // 500us  to hold reset high before assert CKE. change it to 50 for fast simulation time.
      } else {
         APB_Wr(PCTL_TRSTH_ADDR, 50);       
      }
      APB_Wr(PCTL_TRSTL_ADDR, 100);        //  100 clock cycles for reset low 
    do{
        __udelay(1000);
    }
    while (!(APB_Rd(PCTL_POWSTAT_ADDR) & 2)) ; // wait for dll lock

    APB_Wr(PCTL_POWCTL_ADDR, 1);            // start memory power up sequence
    while (!(APB_Rd(PCTL_POWSTAT_ADDR) & 1)) {} // wait for memory power up

    APB_Wr(PCTL_ODTCFG_ADDR, 0xa);         //configure ODT
    
    APB_Wr(PCTL_PHYCR_ADDR, APB_Rd(PCTL_PHYCR_ADDR)&(~((1<<3)|(1<<8))));
  
  //configure the PCTL for DDR2 SDRAM burst length = 4
      APB_Wr(PCTL_MCFG_ADDR,     1 |            // burst length 0 = 4; 1 = 8
                                (0 << 2) |     // bl8int_en.   enable bl8 interrupt function.
                                (1 << 5) |     // 1: ddr3 protocal; 0 : ddr2 protocal
                                (2 <<18) |      // tFAW.
                               (1 << 17) |      // power down exit which fast exit.
                                (0x0 << 8)      // 0xf cycle empty will entry power down mode.
                                        );
    APB_Wr(PCTL_TREFI_ADDR, ddr_setting->t_refi_100ns);
    APB_Wr(PCTL_TMRD_ADDR, 	ddr_setting->t_mrd);
    APB_Wr(PCTL_TRFC_ADDR, 	ddr_setting->t_rfc);
    APB_Wr(PCTL_TRP_ADDR, 	ddr_setting->t_rp);
    APB_Wr(PCTL_TAL_ADDR,  	ddr_setting->t_al);
    APB_Wr(PCTL_TCWL_ADDR,  ddr_setting->t_cwl);
    APB_Wr(PCTL_TCL_ADDR, 	ddr_setting->cl);
    
    APB_Wr(PCTL_TRAS_ADDR, 	ddr_setting->t_ras);
    APB_Wr(PCTL_TRC_ADDR, 	ddr_setting->t_rc);
    APB_Wr(PCTL_TRCD_ADDR, 	ddr_setting->t_rcd);
    APB_Wr(PCTL_TRRD_ADDR, 	ddr_setting->t_rrd);
    APB_Wr(PCTL_TRTP_ADDR, 	ddr_setting->t_rtp);
    APB_Wr(PCTL_TWR_ADDR, 	ddr_setting->t_wr);
    APB_Wr(PCTL_TWTR_ADDR, 	ddr_setting->t_wtr);
    APB_Wr(PCTL_TEXSR_ADDR, ddr_setting->t_exsr);
    APB_Wr(PCTL_TXP_ADDR, 	ddr_setting->t_xp);
    APB_Wr(PCTL_TDQS_ADDR, 	ddr_setting->t_dqs);
    APB_Wr(PCTL_TMOD_ADDR,  ddr_setting->t_mod);
    APB_Wr(PCTL_TZQCL_ADDR, ddr_setting->t_zqcl);
    APB_Wr(PCTL_TCKSRX_ADDR,ddr_setting->t_cksrx);
    APB_Wr(PCTL_TCKSRE_ADDR,ddr_setting->t_cksre);
    APB_Wr(PCTL_TCKE_ADDR,  ddr_setting->t_cke);
    APB_Wr(PCTL_TCKE_ADDR,  ddr_setting->t_cke);
//    APB_Wr(PCTL_TZQCS_ADDR, 64);
//    APB_Wr(PCTL_TZQCSI_ADDR, 4095);
     
       
#if 0   
    unsigned zq=0x3b;
    for(i=0;i<256;i++)
    {
        
        //ZQ calibration 
        
        //wait for ZQ calibration.
        unsigned a;
        unsigned b[4],d,j;
//        do{
            APB_Wr(PCTL_ZQCR_ADDR, ( 1 << 31) | (i <<16) );

            do{
                a=APB_Rd(PCTL_ZQSR_ADDR);
                d=0;
                if(a&(1<<31))
                    d|=1;
                a>>=16;
                for(j=0;j<8;j+=2)
                {
                    if(((a>>j)&0x3)==0)
                      continue;  
                    if(((a>>j)&0x3)==0xf)
                        d|=1;
                   if(((a>>j)&0x3)!=0xf)
                        d|=2;
                }
            
            }while(d&1);
//         }while(d&2);
        
        
        
        
//        while ( APB_Rd(PCTL_ZQSR_ADDR ) & ( 1<<31) ) {}
//            if ( APB_Rd(PCTL_ZQSR_ADDR) & (1 << 30) ) {
//                debug_print("Return\n");
//            return -1;
//        } 
        
        debug_print_hex(i,8);
        debug_print(" ");
        debug_print_hex(a,24);
        debug_print(" ");
        for(d=0;d<4;d++)
        {
            b[d]=(a>>(d*5))&0x1f;
            debug_print_hex(b[d],8);
            debug_print(" ");
        }
        if(b[0]==b[1]&&b[2]==b[3])
        {
            zq=i;
            
            print_ZQ();
            
        }
        debug_print("\n");
        
//        serial_put_hex(i,8);
    }
    //ZQ calibration 
    APB_Wr(PCTL_ZQCR_ADDR, ( 1 << 31) | (zq <<16) );
    
    //wait for ZQ calibration.
    while ( APB_Rd(PCTL_ZQSR_ADDR ) & ( 1<<31) ) {}
        if ( APB_Rd(PCTL_ZQSR_ADDR) & (1 << 30) ) {
        return -1;
    } 
    
#else    
#if 0 
    //ZQ calibration 
    APB_Wr(PCTL_ZQCR_ADDR, ( 1 << 31) | (0x3b <<16) );
   
    //wait for ZQ calibration.
    while ( APB_Rd(PCTL_ZQCR_ADDR ) & ( 1<<31) ) {}
    if ( APB_Rd(PCTL_ZQSR_ADDR) & (1 << 30) ) {
        return -1;
    }
    
#else    
    APB_Wr(PCTL_ZQCR_ADDR, ( 1 << 24) | (0x33dd) );
#endif     
    
#endif                                                  
      // initialize DDR3 SDRAM
//      load_mcmd((1<<31)|(1<<20)|SFT_RESET_CMD);
        load_nop();
        load_mrs(2, mrs2_value);
        load_mrs(3, mrs3_value);
        mrs1_value = mrs1_value & 0xfffffffe; //dll enable 
        load_mrs(1, mrs1_value);
        mrs0_value = mrs0_value | (1 << 8);    // dll reset.
        load_mrs(0, mrs0_value);
        load_zqcl(0);     // send ZQ calibration long command.
        
        return 0;
}