#define hw_training dwc_level_1_hw
static int dwc_level_1_hw(void)
{
    pdm_write(0);
    APB_Wr(PCTL_PHYCR_ADDR, APB_Rd(PCTL_PHYCR_ADDR) | (1<<31));
    dwc_pctl_stat(PCTL_STAT_Config);
    

    dwc_pctl_stat(PCTL_STAT_Access);

    while (APB_Rd(PCTL_PHYCR_ADDR) & (1<<31)) {}
    volatile unsigned aaa;
    aaa=APB_Rd(PCTL_DTURD0_ADDR);
	aaa=APB_Rd(PCTL_DTURD1_ADDR);
	aaa=APB_Rd(PCTL_DTURD2_ADDR);
	aaa=APB_Rd(PCTL_DTURD3_ADDR);
	aaa=APB_Rd(PCTL_PHYSR_ADDR) ;
	debug_print("\nHw Training result");
	debug_print_dword(APB_Rd(PCTL_PHYSR_ADDR)& 0x00340000 );
    if ( APB_Rd(PCTL_PHYSR_ADDR) & 0x00340000 ) {
        return (1);  // failed.
    } else {
        return (0);  // passed.
    }
}

static unsigned char get_best_dtu(unsigned char* p, unsigned char* best)
{
    unsigned char i;

#if 1
    int win_start=-1;
    for(i=0;i<DDR_MAX_WIN_LEN ;i++)
    {

        if(win_start==-1&&(*(p+i)==0x10))
        {
            win_start=i;
        }
        if(win_start!=-1&&(*(p+i)!=0x10))
        {
            break;
        }
    }
    if(win_start==-1)
        return 2;
    *best=(win_start+i)>>1;
//    *best=*best+1>=i?*best:*best+1;
    debug_print("\nGet Windows From ");
    debug_print_hex(win_start,8);
    debug_print(" to ");
    debug_print_hex(i,8);
    debug_print(",best is ");
    debug_print_hex(*best,8);
    debug_print("\n");
    return 0;

#else
    for(i=0;i<=DDR_MAX_WIN_LEN -DDR_RDGR_LEN +1;i++)
    {
        if(*(p+i) + *(p+i+1) + *(p+i+2) == 48)
            goto next;
    }
    return 1;

next:

    for(i=0;i<=DDR_MAX_WIN_LEN -DDR_RDGR_LEN;i++)
    {
        if(*(p+i) + *(p+i+1) + *(p+i+2) + *(p+i+3) == 64)
        {
            if(!i)
                *best = 2;
            else if(i == 8)
                *best = 9;
            else
            {
                if(*(p+i-1)>*(p+i+4))
                    *best = i + 1;
                else
                    *best = i + 2;
            }

            return 0;
        }
    }

    for(i=0;i<=DDR_MAX_WIN_LEN -DDR_RDGR_LEN +1;i++)
    {
        if(*(p+i) + *(p+i+1) + *(p+i+2) == 48)
        {
            *best = i + 1;
            return 0;
        }
    }
#endif
    return 2;
}
#define DDR_RSLR_LEN 6
#define DDR_RDGR_LEN 4
#define DDR_MAX_WIN_LEN (DDR_RSLR_LEN*DDR_RDGR_LEN)

STATIC_PREFIX unsigned dwc_level_1_sw(unsigned lane)
{

	unsigned char chk[DDR_RSLR_LEN*DDR_RDGR_LEN];
	unsigned char result;
	unsigned sl,dqssel;
	unsigned char t;
	int i=0;
    unsigned s,d;


    sl=0;
    /// write once
    print_registers();
//    save_registers(2);
    dwc_pctl_stat(PCTL_STAT_Config);
//    writel(0,P_PCTL_RSLR0_ADDR);
//    writel(0,P_PCTL_RDGR0_ADDR);
    clrsetbits_le32(P_PCTL_RSLR0_ADDR,0x7<<(lane*3),0<<(lane*3));
    pdm_write();
    pdm_dtu_enable(lane,1); //enable write once and read multi mode
    pdm_run(1);
    debug_print("lane ");
    debug_print_hex(lane,4);
    debug_print(" In first level trainning , Write Once\n");

restart:
    for (sl = 0; sl < DDR_RSLR_LEN; sl++) {
		for (dqssel = 0; dqssel < DDR_RDGR_LEN; dqssel++)
		{
            dwc_pctl_stat(PCTL_STAT_Config);
            clrsetbits_le32(P_PCTL_RSLR0_ADDR,0x7<<(lane*3),sl<<(lane*3));
    	    clrsetbits_le32(P_PCTL_RDGR0_ADDR,0x3<<(lane*2),dqssel<<(lane*2));
            pdm_run(0);             //write once

            ddr_start_again=1;

            if(ddr_start_again){
			    debug_print("\ndtu:");
			    debug_print_hex(sl * DDR_RDGR_LEN + dqssel,8);
			    debug_print(" RSLR0=");
                debug_print_hex(APB_Rd(PCTL_RSLR0_ADDR),32);
                debug_print(" RDGR0=");
                debug_print_hex(APB_Rd(PCTL_RDGR0_ADDR),32);
                debug_print(" LEVEL=");
                debug_print_hex(sl * DDR_RDGR_LEN + dqssel,32);
			}
            chk[sl * DDR_RDGR_LEN + dqssel] = check_dtu();
            if(ddr_start_again){
                debug_print(" result:");
                debug_print_hex(chk[sl * DDR_RDGR_LEN + dqssel],8);
                debug_print(" result: ");
                debug_print_hex(readl(P_PCTL_DTUPDES_ADDR),32);
                debug_print(" ");
                print_prd();
//                PCTL_DTUPRD0_ADDR
//            serial_getc();
			}
			ddr_start_again=0;
		}
	}
    debug_print("\nlane");
    debug_print_hex(lane,8);

	if (get_best_dtu(chk, &result)) {
		debug_print(" Fail\n");
		return 1;
	}
	debug_print(" Success");
	debug_print_hex(result,8);

	dwc_pctl_stat(PCTL_STAT_Config);
//	restore_registers(2);
    sl=(result>>2)&7;
    dqssel=(result)&3;
	clrsetbits_le32(P_PCTL_RSLR0_ADDR,0x7<<(lane*3),sl<<(lane*3));
    clrsetbits_le32(P_PCTL_RDGR0_ADDR,0x3<<(lane*2),dqssel<<(lane*2));
    dwc_pctl_stat(PCTL_STAT_Access);
    return 0;
}

