#include <asm/arch/firm/regs.h>
#include <asm/arch/firm/reg_addr.h>
#include <asm/arch/firm/timing.h>
#include <config.h>
#include <asm/arch/firm/io.h>
#include <asm/arch/firm/config.h>
#include <memtest.h>
static void __udelay(unsigned long usec);

#define debug_print(a)  serial_puts(a)
#define debug_print_char(a)  serial_putc(a)

#define debug_print_dword(a)  serial_put_dword(a)
#define debug_print_hex(a,b)  serial_put_hex(a,b)

//3��b0000 = Init_mem 
//3��b0001 = Config 
//3��b0010 = Config_req 
//3��b0011 = Access 
//3��b0100 = Access_req 
//3��b0101 = Low_power 
//3��b0110 = Low_power_entry_req 
//3��b0111 = Low_power_exit_req 
//Others   = Reserved
#define PCTL_STAT_Init_mem           	0
#define PCTL_STAT_Config              1
#define PCTL_STAT_Config_req          2
#define PCTL_STAT_Access              3
#define PCTL_STAT_Access_req          4
#define PCTL_STAT_Low_power           5
#define PCTL_STAT_Low_power_entry_req 6
#define PCTL_STAT_Low_power_exit_req  7

//3'b000 = INIT (move to Init_mem from Config)
//3'b001 = CFG (move to Config from Init_mem or Access)
//3'b010 = GO (move to Access from Config)
//3'b011 = SLEEP (move to Low_power from Access)
//3'b100 = WAKEUP (move to Access from Low_power)

#define PCTL_SCTL_INIT                  0
#define PCTL_SCTL_CFG                   1
#define PCTL_SCTL_GO                    2
#define PCTL_SCTL_SLEEP                 3
#define PCTL_SCTL_WAKEUP 			    4
static void dwc_pctl_stat(unsigned stat)
{
    unsigned cur_stat=readl(P_PCTL_STAT_ADDR);
    switch(stat)
    {
    case PCTL_STAT_Config_req         :
	case PCTL_STAT_Access_req         :
	case PCTL_STAT_Low_power_entry_req:
	case PCTL_STAT_Low_power_exit_req :
	    return;//do nothing , these should not be target stat 
	}
	
	while(cur_stat!=stat)
	{
		switch(cur_stat)
		{
			case PCTL_STAT_Init_mem           :
			    writel(PCTL_SCTL_CFG,P_PCTL_SCTL_ADDR);
			    break;
			case PCTL_STAT_Config             :
			    if(cur_stat>stat)
			        writel(PCTL_SCTL_INIT,P_PCTL_SCTL_ADDR);
			    else
			        writel(PCTL_SCTL_GO,P_PCTL_SCTL_ADDR);
			    break;
			case PCTL_STAT_Access             :
			    if(cur_stat>stat)
			        writel(PCTL_SCTL_CFG,P_PCTL_SCTL_ADDR);
			    else
			        writel(PCTL_SCTL_SLEEP,P_PCTL_SCTL_ADDR);
			    break;
			case PCTL_STAT_Low_power          :
			    writel(PCTL_SCTL_WAKEUP,P_PCTL_SCTL_ADDR);
			    break;
			
		}
		cur_stat=readl(P_PCTL_STAT_ADDR);
		
	}
	return;
}


static char * zqname[]={
    " output pulldown",  
    " output pullup",  
    " on-die pulldown",  
    " on-die pullup"  
};
static void print_ZQ()
{
    unsigned a=APB_Rd(PCTL_ZQSR_ADDR)&0xfffff;
    unsigned t;
    int i;
    debug_print_hex(APB_Rd(PCTL_ZQSR_ADDR),32);
    debug_print(" ");
    for(i=0;i<4;i++)
    {
        
        debug_print(zqname[i]);
        debug_print("=");
        t=(((a>>(i*5))&0x1f));
        debug_print_hex(t,8);
    }
//    debug_print("\n");
}


#define NOP_CMD   0
#define PREA_CMD   1
#define REF_CMD   2
#define MRS_CMD   3
#define ZQ_SHORT_CMD  4
#define ZQ_LONG_CMD   5
#define SFT_RESET_CMD  6

static inline void load_mcmd(unsigned val)
{
	APB_Wr(PCTL_MCMD_ADDR, val);
	int i;
	for(i=0;i<1000;i++);
	while ( APB_Rd(PCTL_MCMD_ADDR) & 0x80000000 );
}
#define load_nop()  load_mcmd((1<<31)|(1<<20)|NOP_CMD)
#define load_prea()  	load_mcmd((1<<31)|(1<<20)|PREA_CMD)
#define load_ref()  	load_mcmd((1<<31)|(1<<20)|REF_CMD)

#define load_mrs(a,b)	load_mcmd((1 << 31) | \
								  (8 << 24) | \
								  (1 << 20) | \
							      (a << 17) | \
						          (b << 4)  | \
								   MRS_CMD )
#define load_zqcl(zq) load_mcmd(  (1 << 31) | \
								  (1 << 20) | \
							      (zq << 4) | \
								  ZQ_LONG_CMD )
static void pdm_write()
{
    static unsigned row=0x1ff0;
    APB_Wr(PCTL_DTUWD0_ADDR, 0xdd22ee11);
    APB_Wr(PCTL_DTUWD1_ADDR, 0x7788bb44);
    APB_Wr(PCTL_DTUWD2_ADDR, 0xdd22ee11);
    APB_Wr(PCTL_DTUWD3_ADDR, 0x7788bb44);
    APB_Wr(PCTL_DTUWACTL_ADDR,	0x300        |  // col addr
                               (0x7<<10)     |  // bank addr
                               (row<<13)  |  // row addr
                               (0 <<30 ));      // rank addr
    APB_Wr(PCTL_DTURACTL_ADDR,	0x300        |  // col addr
                               (0x7<<10)     |  // bank addr
                               (row<<13)  |  // row addr
                               (0 <<30 ));      // rank addr
    row--;  
    row&=0x1fff;                             
//    APB_Wr(PCTL_DTUWDM_ADDR,0xffff);
    
}
static void pdm_dtu_enable(unsigned lane,unsigned wr_rd)
{
    APB_Wr(PCTL_DTUCFG_ADDR, (lane << 10) | 0x01|((wr_rd&1)<<15)); // select byte lane, & enable DTU
}
static void pdm_run(unsigned write)
{
    unsigned this_timeout = TIMERE_GET();
    int i=16;
    
    do{
        dwc_pctl_stat(PCTL_STAT_Config);
        APB_Wr(PCTL_DTUECTL_ADDR, 0x1|((write&1)<<2));     // start wr/rd
        dwc_pctl_stat(PCTL_STAT_Access);
    
        while (TIMERE_SUB(TIMERE_GET(),this_timeout)<256)
        {
            if((APB_Rd(PCTL_DTUECTL_ADDR)&1)==0)
                break;
        }
        write=0;
    }while((APB_Rd(PCTL_DTUPDES_ADDR)&(1<<13))&&i--);
//    while(APB_Rd(PCTL_DTUECTL_ADDR)&1)
//    {
//        if(APB_Rd(PCTL_DTUECTL_ADDR)&2)
//        {    
//            debug_print("g");
//            return;
//        }
//    }
}
static unsigned short dtuprd[8]={0xa9a9,
        0xa6a6,
        0x9a9a,
        0x6a6a,
        0xa9a9,
        0xa6a6,
        0x9a9a,
        0x6a6a,
};
static unsigned check_prd()
{
    int i;
    unsigned ret=0;
    unsigned result[4];
    unsigned short * p;
    for(i=0;i<4;i++)
        result[i]=APB_Rd(PCTL_DTUPRD0_ADDR+(i<<2));
    p=(unsigned short*)&result[0];
    for(i=0;i<8;i++)
        ret|=(p[i]!=dtuprd[i]?1:0)<<i;
    return ret;
}
static inline unsigned char check_dtu(void)
{
    unsigned char r_num = 0;
    volatile char *pr, *pw;
    unsigned r[4],w[4];
    unsigned char i;
    volatile unsigned * rd;
    volatile unsigned * wd;
    rd = (volatile unsigned *)APB_REG_ADDR(PCTL_DTURD0_ADDR);
    wd = (volatile unsigned *)APB_REG_ADDR(PCTL_DTUWD0_ADDR);
    for(i=0;i<4;i++)
    {
        r[i]=*(rd+i);
        w[i]=*(wd+i);
    }
    
    pr = (volatile char *)&r[0];
    pw = (volatile char *)&w[0];
    for(i=0;i<16;i++)
    {
        if(*(pr+i) == *(pw+i))
            ++r_num;
    }
    if(0)
    {
        
        for(i=0;i<16;i++)
        {
            if(i==8)
                debug_print("\n");
            debug_print("[");
            debug_print_hex(i,4);
            debug_print("]=");
            debug_print_hex(*(pr+i),8);
            debug_print(" ");
            debug_print_hex(*(pw+i),8);
            debug_print(" ");
            
        }
    }
    
    return r_num;
}
static void print_registers()
{
    int i;
    unsigned max=readl(P_PCTL_IOCR_ADDR)>>8;
    debug_print("\nZQSR=");
    print_ZQ();
    debug_print("\nRSLR0=");
    debug_print_hex(APB_Rd(PCTL_RSLR0_ADDR),32);
    debug_print(" RDGR0=");
    debug_print_hex(APB_Rd(PCTL_RDGR0_ADDR),32);

    debug_print("\nDQSTR=");
    debug_print_hex(APB_Rd(PCTL_DQSTR_ADDR),32);
    debug_print(" DQSNTR=");
    debug_print_hex(APB_Rd(PCTL_DQSNTR_ADDR),32);
    
    for(i=0;i<8;i++)
    {
        if(((1<<i)&max)==0)
            continue;
        debug_print("\nDLLCR");
        debug_print_hex(i,4);
        debug_print("=");
        debug_print_hex(APB_Rd(PCTL_DLLCR0_ADDR+(i<<2)),32);
        debug_print(" DQTR");
        debug_print_hex(i,4);
        debug_print("=");
        debug_print_hex(APB_Rd(PCTL_DQTR0_ADDR+(i<<2)),32);
    
    }
    debug_print("\n");

}

static unsigned save[16];
void save_registers(unsigned max)
{
    int i=0,j;
    
    
    save[i++]=APB_Rd(PCTL_RSLR0_ADDR);
    save[i++]=APB_Rd(PCTL_RDGR0_ADDR);

    save[i++]=APB_Rd(PCTL_DQSTR_ADDR);
    save[i++]=APB_Rd(PCTL_DQSNTR_ADDR);
    
    for(j=0;j<max;j++)
    {
        save[i++]=APB_Rd(PCTL_DLLCR0_ADDR+(j<<2));
        save[i++]=APB_Rd(PCTL_DQTR0_ADDR+(j<<2));
    
    }
}

void restore_registers(unsigned max)
{
    int i=0,j;
    
    
    APB_Wr(PCTL_RSLR0_ADDR,save[i++]);
    APB_Wr(PCTL_RDGR0_ADDR,save[i++]);

    APB_Wr(PCTL_DQSTR_ADDR,save[i++]);
    APB_Wr(PCTL_DQSNTR_ADDR,save[i++]);
    
    for(j=0;j<max;j++)
    {
        APB_Wr(PCTL_DLLCR0_ADDR+(j<<2),save[i++]);
        APB_Wr(PCTL_DQTR0_ADDR+(j<<2),save[i++]);
    
        
    }
}

static void print_prd()
{
    int i;
    unsigned ret=0;
    unsigned result[4];
    unsigned short * p;
    for(i=0;i<4;i++)
        result[i]=APB_Rd(PCTL_DTUPRD0_ADDR+(i<<2));
    p=(unsigned short*)&result[0];
    for(i=0;i<8;i++)
        serial_put_hex(*(p+i),16);
}
static void print_dtu()
{
    int i;
    unsigned ret=0;
    unsigned result[4];
    unsigned char * p;
    for(i=0;i<4;i++)
        result[i]=APB_Rd(PCTL_DTURD0_ADDR+(i<<2));
    p=(unsigned char*)&result[0];
    for(i=0;i<16;i++)
        serial_put_hex(*(p+i),8);
    
}